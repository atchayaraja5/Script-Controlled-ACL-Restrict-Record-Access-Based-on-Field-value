SCRIPT-CONTROLLED ACL – RESTRICT RECORD ACCESS BASED ON FIELD VALUE

Team ID: SWTID-2026-4817
Team Size: 4
Team Leader: ATCHAYA. R
Team Members:
- ATHUNA PARVEEN. N
- SWETHA D
- AAYISHA AFRIN

Scenario:
Only users belonging to the EEE branch can read records whose Branch field is EEE.
Administrators retain full access.

NOTE:
The exact target table and technical Branch field name are not specified in the
provided lab sheet. Replace example names such as u_branch with the actual
field name in your ServiceNow instance.
